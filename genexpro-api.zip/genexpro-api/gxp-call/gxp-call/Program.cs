﻿using System;
using gxps5api.Simple;

namespace gxp_call
{
    class Program
    {

        private static string ReadRun(String dataset, int head, int genes, int fold)
        {
            string template = @"C:\DOKTORAT\PIPELINE\data.gep_old1\DATASET_HEAD_GENES_FOLD\DATASET_template_classification_000001.gep";
            template = template.Replace("DATASET", dataset);
            template = template.Replace("HEAD", head.ToString());
            template = template.Replace("GENES", genes.ToString());
            template = template.Replace("FOLD", fold.ToString());

            Console.WriteLine(template);
            var run = RunFactory.OpenRun(template);
            var tp = run.ActiveModel.ValidationStatistics.TruePositives;
            var tn = run.ActiveModel.ValidationStatistics.TrueNegatives;
            var fn = run.ActiveModel.ValidationStatistics.FalseNegatives;
            var fp = run.ActiveModel.ValidationStatistics.FalsePositives;
            var acc = run.ActiveModel.ValidationStatistics.Accuracy/100;
            var headgene = "g"+genes.ToString() + " h" + head.ToString();
            float sens = (float)tp / ((float)tp + (float)fn);
            float spec = (float)tn / ((float)tn + (float)fp);
            //return dataset + "," + head + "," + genes + "," + headgene + "," + fold + "," + acc + "," + tp + "," + tn + "," + fn + "," + fp + "," + sens + "," + spec + "\n";
            return dataset + "," + head + "," + genes + "," + headgene + "," + fold + "," + acc + "," + tp + "," + tn + "," + fn + "," + fp + "," + sens + "," + spec + "\n";
        }

        private class Parameters
        {
            public Parameters(string dataset, int head, int genes)
            {
                this.dataset = dataset;
                this.head = head;
                this.genes = genes;
            }
            public string dataset;
            public int head;
            public int genes;
        }

        static void Main(string[] args)
        {
            
            //var datasets = new Parameters[] { new Parameters("bwc", 6, 6), new Parameters("climate", 3, 5), new Parameters("diabetes", 6, 6)};
            //var datasets = new Parameters[] { new Parameters("ionosphere", 3, 6), new Parameters("promise_cm1", 3, 5), new Parameters("promise_jm1", 3, 5) };
            //var datasets = new Parameters[] { new Parameters("promise_kc1", 3, 5), new Parameters("promise_kc2", 3, 5), new Parameters("promise_pc1", 3, 5) };
            //var datasets = new Parameters[] { new Parameters("sonar", 6, 6), new Parameters("spam", 6, 6), new Parameters("transfusion", 3, 5) };
            //var datasets = new Parameters[] { new Parameters("vertebral", 6, 6), new Parameters("vote", 6, 6), new Parameters("wine_red", 3, 5), new Parameters("wine_white", 3, 5) };
            var datasets = new Parameters[] { new Parameters("hazelcast", 6, 6)};

            for (int i = 0; i < datasets.Length; i++)
            {
                string text = "dataset,head,genes,headgene, fold,acc,tp,tn,fn,fp,sens,spec\n";
                string dataset = datasets[i].dataset;
                for (int head = 1; head <= datasets[i].head; head++)
                {
                    for (int genes = 1; genes <= datasets[i].genes; genes++)
                    {
                        for (int fold = 1; fold < 11; fold++)
                        {
                            text += ReadRun(dataset, head, genes, fold);
                        }
                    }
                }
                System.IO.File.WriteAllText(@"C:\DOKTORAT\PIPELINE\data.gep.output\output.gep." + dataset + ".csv", text);
            }
            
        }
    }
}
